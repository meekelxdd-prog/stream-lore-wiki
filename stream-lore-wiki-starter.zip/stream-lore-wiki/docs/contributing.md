# Contributing

How to add new pages and edit content.