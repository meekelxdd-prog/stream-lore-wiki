# Glossary

Definitions for terms and commands.