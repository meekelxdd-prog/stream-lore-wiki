---
title: Character Name
tags:
  - character
summary: A short summary.
---

# {{ title }}

Describe the character here.